import requests, json
import shutil
import os
import cv2
import numpy as np
import time

"""
API_HOST = '[API_SERVER]'
headers = {
    'Access-Token': '[YOUR_ACCESS_TOKEN]',
    'Content-Type': 'application/json'
}
"""
API_HOST = 'http://localhost:5000'
headers = {
    'Access-Token': 'ABCDEFGH12345678',
    'Content-Type': 'application/json'
}

number_directory = 'numbers/'
if not os.path.exists(number_directory):
    os.makedirs(number_directory)

image_directory = 'images/'
if not os.path.exists(image_directory):
    os.makedirs(image_directory)

# 미리 모든 수(number)에 대한 이미지 불러오기
numbers = []
for number in range(1, 65):
    img = cv2.imread(number_directory + str(number).zfill(2) + '.png')
    numbers.append(img)


# 두 이미지가 같은지 확인하는 함수
def is_same(img1, img2):
    if img1.shape != img2.shape:
        return False
    if np.bitwise_xor(img1, img2).any():
        return False
    return True


# 한 장의 이미지가 어떤 수에 해당하는지 알려주는 함수
def find(img):
    for i in range(64):
        if is_same(img, numbers[i]):
            return i + 1
    return -1


# 이미지 경로(path), 이미지의 크기(N), 목표 행(target), 연산자들(operators)
def calculate(path, n, target, operators):
    # 하나의 이미지가 주어졌을 때 N X N 크기로 나누기
    img = cv2.imread(image_directory + path)
    height, width, channel = img.shape
    size = height // n # 각 부분 격자의 이미지 크기(size)

    # 전체 이미지를 각 size X size의 이미지들로 분할
    rows = []
    for i in range(n):
        row = []
        for j in range(n):
            row.append(img[i * size:(i + 1) * size, j * size: (j + 1) * size,:])
        rows.append(row)

    # 각 부분 격자에 포함된 이미지에 대하여 수(number) 계산
    arr = []
    for i in range(n):
        row = []
        for j in range(n):
            arr.append(find(rows[i][j]))

    # 목표 행(target row)에 대해 정답 계산하기
    data = arr[target * n:target * n + n]
    answer = data[0]
    for i in range(n - 1):
        if operators[i] == '+':
            answer += data[i + 1]
        elif operators[i] == '*':
            answer *= data[i + 1]
    return answer


def request(path, method, data={}):
    url = API_HOST + path
    print(f'Request URL: {url}')
    print(f'HTTP Method: {method}')
    print(f'Headers: {headers}')

    if method == 'GET':
        return requests.get(url, headers=headers, stream=True)
    elif method == 'POST':
        print(f'Sended data: {data}')
        return requests.post(url, headers=headers, data=json.dumps(data))


# auth_key를 발급 받고, 문제 풀이 시작
start_time = time.time()
response = request('/start', 'GET')
print(f'Response status: {response.status_code}')
data = response.json()
key = data['auth_key']

while True:
    print('==============================================')
    # 서버(server)로부터 받은 데이터 확인
    print(f'Current: {data}')
    if 'result' in data:
        result = data['result']
        if result == 'correct':
            print('[Result] Correct answer!')
        elif result == 'wrong':
            print('[Result] Wrong answer!')
        elif result == 'time over':
            print('[Result] Time over!')
            break
        else: # flag를 찾은 경우 종료
            print(f'[Result] FLAG: {result}')
            break
    stage = data['stage']
    filename = data['image']
    n = data['n']
    target = data['target']
    operators = data['operators']

    # 서버(server)로부터 이미지 다운로드
    response = request('/image?filename=' + filename, 'GET')
    print(f'Response status: {response.status_code}')
    if response.status_code == 200:
        with open(image_directory + filename, 'wb') as f:
            response.raw.decode_content = True
            shutil.copyfileobj(response.raw, f)
    
    # 정답 계산
    oper = [operators[i] for i in range(n - 1)]
    answer = calculate(path=filename, n=n, target=target, operators=oper)

    # 서버(server)에 정답 전송
    data = {
        'auth_key': key,
        'value': answer
    }
    response = request('/query', 'POST', data)
    print(f'Response status: {response.status_code}')
    data = response.json()
    print("[Log] Elapsed time:", time.time() - start_time, "seconds.")
