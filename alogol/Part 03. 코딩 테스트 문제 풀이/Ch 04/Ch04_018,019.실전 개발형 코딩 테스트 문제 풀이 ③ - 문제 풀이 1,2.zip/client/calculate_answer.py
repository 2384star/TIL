import numpy as np
import cv2
import os

number_directory = 'numbers/'
if not os.path.exists(number_directory):
    os.makedirs(number_directory)

image_directory = 'images/'
if not os.path.exists(image_directory):
    os.makedirs(image_directory)

# 미리 모든 수(number)에 대한 이미지 불러오기
numbers = []
for number in range(1, 65):
    img = cv2.imread(number_directory + str(number).zfill(2) + '.png')
    numbers.append(img)


# 두 이미지가 같은지 확인하는 함수
def is_same(img1, img2):
    if img1.shape != img2.shape:
        return False
    if np.bitwise_xor(img1, img2).any():
        return False
    return True


# 한 장의 이미지가 어떤 수에 해당하는지 알려주는 함수
def find(img):
    for i in range(64):
        if is_same(img, numbers[i]):
            return i + 1
    return -1


# 이미지 경로(path), 이미지의 크기(N), 목표 행(target), 연산자들(operators)
def calculate(path, n, target, operators):
    # 하나의 이미지가 주어졌을 때 N X N 크기로 나누기
    img = cv2.imread(image_directory + path)
    height, width, channel = img.shape
    size = height // n # 각 부분 격자의 이미지 크기(size)

    # 전체 이미지를 각 size X size의 이미지들로 분할
    rows = []
    for i in range(n):
        row = []
        for j in range(n):
            row.append(img[i * size:(i + 1) * size, j * size: (j + 1) * size,:])
        rows.append(row)

    # 각 부분 격자에 포함된 이미지에 대하여 수(number) 계산
    arr = []
    for i in range(n):
        row = []
        for j in range(n):
            arr.append(find(rows[i][j]))

    # 목표 행(target row)에 대해 정답 계산하기
    data = arr[target * n:target * n + n]
    answer = data[0]
    for i in range(n - 1):
        if operators[i] == '+':
            answer += data[i + 1]
        elif operators[i] == '*':
            answer *= data[i + 1]
    return answer


answer = calculate(path='result.png', n=8, target=2, operators=['+', '*', '+', '*', '*', '*', '+'])
print(answer)
