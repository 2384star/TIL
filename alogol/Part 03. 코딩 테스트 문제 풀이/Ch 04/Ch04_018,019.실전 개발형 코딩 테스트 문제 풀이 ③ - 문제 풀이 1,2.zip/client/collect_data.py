import requests, json
import shutil
import os
import cv2
import numpy as np

"""
API_HOST = '[API_SERVER]'
headers = {
    'Access-Token': '[YOUR_ACCESS_TOKEN]',
    'Content-Type': 'application/json'
}
"""
API_HOST = 'http://localhost:5000'
headers = {
    'Access-Token': 'ABCDEFGH12345678',
    'Content-Type': 'application/json'
}

number_directory = 'numbers/'
if not os.path.exists(number_directory):
    os.makedirs(number_directory)

image_directory = 'images/'
if not os.path.exists(image_directory):
    os.makedirs(image_directory)


def request(path, method, data={}):
    url = API_HOST + path
    print(f'Request URL: {url}')
    print(f'HTTP Method: {method}')
    print(f'Headers: {headers}')

    if method == 'GET':
        return requests.get(url, headers=headers, stream=True)
    elif method == 'POST':
        print(f'Sended data: {data}')
        return requests.post(url, headers=headers, data=json.dumps(data))


# auth_key를 발급 받고, 문제 풀이 시작
response = request('/start', 'GET')
print(f'Response status: {response.status_code}')
data = response.json()
key = data['auth_key']

n = data['n']
filename = data['image']

# 서버(server)로부터 이미지 다운로드
response = request('/image?filename=' + filename, 'GET')
print(f'Response status: {response.status_code}')
if response.status_code == 200:
    with open(image_directory + filename, 'wb') as f:
        response.raw.decode_content = True
        shutil.copyfileobj(response.raw, f)

# 하나의 이미지가 주어졌을 때 N X N 크기로 나누기
img = cv2.imread(image_directory + filename)
height, width, channel = img.shape
size = height // n # 각 부분 격자의 이미지 크기(size)

# 전체 이미지를 각 size X size의 이미지들로 분할
cnt = 0
for i in range(n):
    for j in range(n):
        current = img[i * size:(i + 1) * size, j * size: (j + 1) * size,:]
        cv2.imwrite(number_directory + str(cnt) + '.png', current)
        cnt += 1
