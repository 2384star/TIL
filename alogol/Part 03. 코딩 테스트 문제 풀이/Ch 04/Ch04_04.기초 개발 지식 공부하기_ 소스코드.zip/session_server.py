from flask import Flask, jsonify, session

app = Flask(__name__)
app.secret_key = "ABCDEFGH"


# 장바구니에 물품 담기
@app.route('/add/<product_id>')
def add(product_id):
    if 'cart' not in session: # 장바구니가 비어있다면
        session['cart'] = [product_id]
    else: # 장바구니에 새로운 물품 추가
        cart = session['cart']
        cart.append(product_id)
        session['cart'] = cart
    data = {
        'status': 'success',
        'product_id': product_id
    }
    return jsonify(data)


# 장바구니에 담긴 물품 목록 확인
@app.route('/list/')
def list():
    cart = []
    if 'cart' in session:
        cart = session['cart']
    data = {
        'status': 'success',
        'cart': cart
    }
    return jsonify(data)


@app.route('/clear/')
def clear():
    # 세션(session) 정보 삭제
    session.pop('cart', None)
    data = {
        'status': 'success'
    }
    return jsonify(data)


app.run(host="localhost", port=5000)