from flask import Flask, jsonify

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False # 한글 출력


user_list = [
    '홍길동',
    '나동빈',
    '이순신'
]

# 사용자 목록 조회
@app.route('/user/')
def user():
    data = {
        'status': 'success',
        'user_list': user_list
    }
    return jsonify(data)


# 사용자 추가
@app.route('/user/add/<username>')
def add(username):
    user_list.append(username)
    data = {
        'status': 'success',
        'username': username
    }
    return jsonify(data)


# 사용자 제거
@app.route('/user/delete/<username>')
def delete(username):
    if username in user_list:
        user_list.remove(username)
        status = 'success'
    else:
        status = 'not exist'
    data = {
        'status': status
    }
    return jsonify(data)


app.run(host="localhost", port=5000)