import requests, json

"""
API_HOST = '[API_SERVER]'
headers = {
    'Access-Token': '[YOUR_ACCESS_TOKEN]',
    'Content-Type': 'application/json'
}
"""
API_HOST = 'http://localhost:5000'
headers = {
    'Access-Token': 'ABCDEFGH12345678',
    'Content-Type': 'application/json'
}

def request(path, method, data={}):
    url = API_HOST + path
    print(f'Request URL: {url}')
    print(f'HTTP Method: {method}')
    print(f'Headers: {headers}')

    if method == 'GET':
        return requests.get(url, headers=headers)
    elif method == 'POST':
        print(f'Sended data: {data}')
        return requests.post(url, headers=headers, data=json.dumps(data))


# auth_key를 발급 받고, 문제 풀이 시작
response = request('/start', 'GET')
print(f'Response status: {response.status_code}')
data = response.json()
print(f'Response: {data}')
key = data['auth_key']

# 서버(server)에 보낼 데이터 생성
data = {
    'auth_key': key
}

# 서버에 데이터를 전송한 뒤에 응답(response) 받기
print('==============================================')
response = request('/query', 'POST', data)
print(f'Response status: {response.status_code}')
data = response.json()
print(f'Response: {data}')